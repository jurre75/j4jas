# mojo-server-threaded
[![Appveyor build status](https://ci.appveyor.com/api/projects/status/3yn5979hh30svwib?svg=true)](https://ci.appveyor.com/project/tomk3003/mojo-server-threaded)

Alternatives to Mojo::Server::Prefork and Mojo::Server::Hypnotoad for Windows.

[Documentation on Metacpan](https://metacpan.org/pod/Mojo::Server::Threaded)
